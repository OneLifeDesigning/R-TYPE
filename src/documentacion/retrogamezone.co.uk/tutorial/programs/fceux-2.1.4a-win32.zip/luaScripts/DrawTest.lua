while true do
z = zapper.read()
gui.text(z.x,z.y,"Boo\nBoo\nBoooooooooooo");
emu.frameadvance();
end