AminGet Version 1.1

Use this programm to grab animations from Zelda 3 or other 2D games.
Just start with the menu entry Observe->Start and change to the game's window.
The programm will make a screenshot every 10 milliseconds and compares it to the last.
If it has changed it will be saved in memory. You can save all screenshots into 
the 'shots' directory with the menu entry 'Screen Sots->Save'.

Attention! Make the game windows as small as possible to keep the screenshot 
small, disable every background layer you don't need and turn off the frame 
counter, or the program will make lot's of useless screenshots!

Programmed 2002 by Michael Menne (zyx@pcpmenne.de) for the Zelda 3 Clone project.


Copyright (c) 2002, Michael Menne
All rights reserved.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 


